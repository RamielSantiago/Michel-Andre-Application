﻿CREATE TABLE [dbo].[ELC]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [empid] INT NOT NULL, 
    [credit] INT NOT NULL, 
    [consume] INT NOT NULL, 
    [balance] INT NOT NULL, 
    [year] INT NOT NULL, 
    [remarks] VARCHAR(50) NOT NULL, 
    [leave_code] VARCHAR(50) NOT NULL, 
    [leave_name] VARCHAR(50) NOT NULL
)
