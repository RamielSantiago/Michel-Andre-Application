﻿CREATE TABLE [dbo].[LeaveReq]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [lid] NCHAR(10) NOT NULL, 
    [empid] INT NOT NULL, 
    [fdate] DATE NOT NULL, 
    [leave_type] VARCHAR(50) NOT NULL, 
    [leave_date] DATE NOT NULL, 
    [time_from] TIME NOT NULL, 
    [time_to] TIME NOT NULL, 
    [total_hrs] INT NOT NULL, 
    [status] VARCHAR(50) NOT NULL, 
    [inputby] VARCHAR(50) NOT NULL, 
    [inputdate] DATE NOT NULL, 
    [modby] VARCHAR(50) NOT NULL, 
    [moddate] DATE NOT NULL, 
    [post] VARCHAR(50) NOT NULL, 
    [postdate] DATE NOT NULL, 
    [remarks] TEXT NOT NULL, 
    [pay] FLOAT NOT NULL, 
    [leave_desc] TEXT NOT NULL, 
    [year] INT NOT NULL, 
    [payment] FLOAT NOT NULL
)
