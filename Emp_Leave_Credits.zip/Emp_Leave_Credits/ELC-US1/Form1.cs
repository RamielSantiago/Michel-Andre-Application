﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ELC_US1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void eLCBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.eLCBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.employee_Leave_CreditsDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'employee_Leave_CreditsDataSet1.LeaveReq' table. You can move, or remove it, as needed.
            this.leaveReqTableAdapter.Fill(this.employee_Leave_CreditsDataSet1.LeaveReq);
            // TODO: This line of code loads data into the 'employee_Leave_CreditsDataSet.ELC' table. You can move, or remove it, as needed.
            this.eLCTableAdapter.Fill(this.employee_Leave_CreditsDataSet.ELC);

        }

        private void eLCDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
