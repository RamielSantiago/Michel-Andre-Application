﻿namespace HRMS.View.UI.EmployeeList
{
    partial class updateEmployee
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(updateEmployee));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.fname = new System.Windows.Forms.TextBox();
            this.lName = new System.Windows.Forms.TextBox();
            this.MI = new System.Windows.Forms.TextBox();
            this.uName = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.username = new System.Windows.Forms.TextBox();
            this.regpass = new System.Windows.Forms.TextBox();
            this.email = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.regconpass = new System.Windows.Forms.TextBox();
            this.position = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dept = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.hiredate = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.upEmpBtn = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.eID = new System.Windows.Forms.TextBox();
            this.editDate = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Franklin Gothic Book", 14F);
            this.label1.Location = new System.Drawing.Point(158, 218);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 30);
            this.label1.TabIndex = 47;
            this.label1.Text = "First Name";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Franklin Gothic Book", 14F);
            this.label2.Location = new System.Drawing.Point(731, 218);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 30);
            this.label2.TabIndex = 48;
            this.label2.Text = "Last Name";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Franklin Gothic Book", 14F);
            this.label3.Location = new System.Drawing.Point(447, 218);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 30);
            this.label3.TabIndex = 49;
            this.label3.Text = "Middle Name";
            // 
            // fname
            // 
            this.fname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.fname.BackColor = System.Drawing.Color.LightSkyBlue;
            this.fname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fname.Font = new System.Drawing.Font("Franklin Gothic Book", 12F);
            this.fname.ForeColor = System.Drawing.Color.Black;
            this.fname.Location = new System.Drawing.Point(163, 261);
            this.fname.Name = "fname";
            this.fname.Size = new System.Drawing.Size(239, 30);
            this.fname.TabIndex = 50;
            // 
            // lName
            // 
            this.lName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lName.BackColor = System.Drawing.Color.LightSkyBlue;
            this.lName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lName.Font = new System.Drawing.Font("Franklin Gothic Book", 12F);
            this.lName.ForeColor = System.Drawing.Color.Black;
            this.lName.Location = new System.Drawing.Point(736, 261);
            this.lName.Name = "lName";
            this.lName.Size = new System.Drawing.Size(273, 30);
            this.lName.TabIndex = 51;
            // 
            // MI
            // 
            this.MI.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.MI.BackColor = System.Drawing.Color.LightSkyBlue;
            this.MI.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MI.Font = new System.Drawing.Font("Franklin Gothic Book", 12F);
            this.MI.ForeColor = System.Drawing.Color.Black;
            this.MI.Location = new System.Drawing.Point(452, 261);
            this.MI.Name = "MI";
            this.MI.Size = new System.Drawing.Size(239, 30);
            this.MI.TabIndex = 52;
            // 
            // uName
            // 
            this.uName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.uName.AutoSize = true;
            this.uName.Font = new System.Drawing.Font("Franklin Gothic Book", 14F);
            this.uName.Location = new System.Drawing.Point(158, 346);
            this.uName.Name = "uName";
            this.uName.Size = new System.Drawing.Size(119, 30);
            this.uName.TabIndex = 53;
            this.uName.Text = "Username";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Franklin Gothic Book", 14F);
            this.label5.Location = new System.Drawing.Point(731, 346);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 30);
            this.label5.TabIndex = 54;
            this.label5.Text = "Password^";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Franklin Gothic Book", 14F);
            this.label4.Location = new System.Drawing.Point(447, 346);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 30);
            this.label4.TabIndex = 55;
            this.label4.Text = "Email";
            // 
            // username
            // 
            this.username.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.username.BackColor = System.Drawing.Color.LightSkyBlue;
            this.username.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.username.Font = new System.Drawing.Font("Franklin Gothic Book", 12F);
            this.username.ForeColor = System.Drawing.Color.Black;
            this.username.Location = new System.Drawing.Point(163, 389);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(239, 30);
            this.username.TabIndex = 56;
            // 
            // regpass
            // 
            this.regpass.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.regpass.BackColor = System.Drawing.Color.LightSkyBlue;
            this.regpass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.regpass.Font = new System.Drawing.Font("Franklin Gothic Book", 12F);
            this.regpass.ForeColor = System.Drawing.Color.Black;
            this.regpass.Location = new System.Drawing.Point(736, 389);
            this.regpass.Name = "regpass";
            this.regpass.PasswordChar = '*';
            this.regpass.Size = new System.Drawing.Size(273, 30);
            this.regpass.TabIndex = 57;
            // 
            // email
            // 
            this.email.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.email.BackColor = System.Drawing.Color.LightSkyBlue;
            this.email.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.email.Font = new System.Drawing.Font("Franklin Gothic Book", 12F);
            this.email.ForeColor = System.Drawing.Color.Black;
            this.email.Location = new System.Drawing.Point(452, 389);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(239, 30);
            this.email.TabIndex = 58;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Franklin Gothic Book", 14F);
            this.label6.Location = new System.Drawing.Point(731, 475);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(208, 30);
            this.label6.TabIndex = 59;
            this.label6.Text = "Confirm Password^";
            // 
            // regconpass
            // 
            this.regconpass.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.regconpass.BackColor = System.Drawing.Color.LightSkyBlue;
            this.regconpass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.regconpass.Font = new System.Drawing.Font("Franklin Gothic Book", 12F);
            this.regconpass.ForeColor = System.Drawing.Color.Black;
            this.regconpass.Location = new System.Drawing.Point(736, 518);
            this.regconpass.Name = "regconpass";
            this.regconpass.PasswordChar = '*';
            this.regconpass.Size = new System.Drawing.Size(273, 30);
            this.regconpass.TabIndex = 60;
            // 
            // position
            // 
            this.position.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.position.BackColor = System.Drawing.Color.LightSkyBlue;
            this.position.Cursor = System.Windows.Forms.Cursors.Hand;
            this.position.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.position.Font = new System.Drawing.Font("Franklin Gothic Book", 12F);
            this.position.ForeColor = System.Drawing.Color.Black;
            this.position.FormattingEnabled = true;
            this.position.Location = new System.Drawing.Point(163, 617);
            this.position.Name = "position";
            this.position.Size = new System.Drawing.Size(527, 33);
            this.position.TabIndex = 61;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Franklin Gothic Book", 14F);
            this.label7.Location = new System.Drawing.Point(158, 574);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(105, 30);
            this.label7.TabIndex = 62;
            this.label7.Text = "Position^";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Franklin Gothic Book", 14F);
            this.label8.Location = new System.Drawing.Point(158, 474);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(148, 30);
            this.label8.TabIndex = 63;
            this.label8.Text = "Department^";
            // 
            // dept
            // 
            this.dept.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dept.BackColor = System.Drawing.Color.LightSkyBlue;
            this.dept.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dept.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dept.Font = new System.Drawing.Font("Franklin Gothic Book", 12F);
            this.dept.ForeColor = System.Drawing.Color.Black;
            this.dept.FormattingEnabled = true;
            this.dept.Items.AddRange(new object[] {
            "President",
            "General Manager",
            "Accounting",
            "Retail Sales Operation",
            "Audit",
            "MIS",
            "Administration",
            "Purchasing",
            "Merchandising",
            "HRMD",
            "Marketing",
            "Creative",
            "Warehouse and Logistics",
            "MCE Production",
            "MCE Quality Assurance"});
            this.dept.Location = new System.Drawing.Point(163, 511);
            this.dept.Name = "dept";
            this.dept.Size = new System.Drawing.Size(256, 33);
            this.dept.TabIndex = 64;
            this.dept.SelectedIndexChanged += new System.EventHandler(this.dept_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Franklin Gothic Book", 14F);
            this.label9.Location = new System.Drawing.Point(447, 474);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(123, 30);
            this.label9.TabIndex = 65;
            this.label9.Text = "Date Hired";
            // 
            // hiredate
            // 
            this.hiredate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.hiredate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.hiredate.Font = new System.Drawing.Font("Franklin Gothic Book", 10F);
            this.hiredate.Location = new System.Drawing.Point(452, 518);
            this.hiredate.Name = "hiredate";
            this.hiredate.Size = new System.Drawing.Size(265, 26);
            this.hiredate.TabIndex = 66;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Sitka Text", 12F);
            this.label10.Location = new System.Drawing.Point(158, 101);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(836, 87);
            this.label10.TabIndex = 67;
            this.label10.Text = "Fields with (*) are required.\r\nFields with (^) also require the field directly be" +
    "low it filled to be considered for update.\r\nFields left blank will not be update" +
    "d.\r\n";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // upEmpBtn
            // 
            this.upEmpBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.upEmpBtn.BackColor = System.Drawing.Color.Transparent;
            this.upEmpBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("upEmpBtn.BackgroundImage")));
            this.upEmpBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.upEmpBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.upEmpBtn.Location = new System.Drawing.Point(468, 667);
            this.upEmpBtn.Name = "upEmpBtn";
            this.upEmpBtn.Size = new System.Drawing.Size(223, 69);
            this.upEmpBtn.TabIndex = 68;
            this.upEmpBtn.UseVisualStyleBackColor = false;
            this.upEmpBtn.Click += new System.EventHandler(this.upEmpBtn_Click);
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Franklin Gothic Book", 14F);
            this.label11.Location = new System.Drawing.Point(731, 574);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(155, 30);
            this.label11.TabIndex = 69;
            this.label11.Text = "Employee ID*";
            // 
            // eID
            // 
            this.eID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.eID.BackColor = System.Drawing.Color.LightSkyBlue;
            this.eID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.eID.Font = new System.Drawing.Font("Franklin Gothic Book", 12F);
            this.eID.ForeColor = System.Drawing.Color.Black;
            this.eID.Location = new System.Drawing.Point(736, 617);
            this.eID.Name = "eID";
            this.eID.Size = new System.Drawing.Size(273, 30);
            this.eID.TabIndex = 70;
            // 
            // editDate
            // 
            this.editDate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.editDate.AutoSize = true;
            this.editDate.Location = new System.Drawing.Point(576, 482);
            this.editDate.Name = "editDate";
            this.editDate.Size = new System.Drawing.Size(59, 20);
            this.editDate.TabIndex = 71;
            this.editDate.Text = "Edit?";
            this.editDate.UseVisualStyleBackColor = true;
            this.editDate.CheckedChanged += new System.EventHandler(this.editDate_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.editDate);
            this.panel1.Controls.Add(this.eID);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.upEmpBtn);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.hiredate);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.dept);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.position);
            this.panel1.Controls.Add(this.regconpass);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.email);
            this.panel1.Controls.Add(this.regpass);
            this.panel1.Controls.Add(this.username);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.uName);
            this.panel1.Controls.Add(this.MI);
            this.panel1.Controls.Add(this.lName);
            this.panel1.Controls.Add(this.fname);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1132, 858);
            this.panel1.TabIndex = 47;
            // 
            // updateEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Name = "updateEmployee";
            this.Size = new System.Drawing.Size(1132, 858);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox fname;
        private System.Windows.Forms.TextBox lName;
        private System.Windows.Forms.TextBox MI;
        private System.Windows.Forms.Label uName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox username;
        private System.Windows.Forms.TextBox regpass;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox regconpass;
        private System.Windows.Forms.ComboBox position;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox dept;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker hiredate;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button upEmpBtn;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox eID;
        private System.Windows.Forms.CheckBox editDate;
        private System.Windows.Forms.Panel panel1;
    }
}
